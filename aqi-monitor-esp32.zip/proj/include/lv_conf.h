#ifndef LV_CONF_H
#define LV_CONF_H

#include <stdint.h>

#define LV_COLOR_DEPTH          16
#define LV_COLOR_16_SWAP        0

#define LV_MEM_CUSTOM           1

#define LV_TICK_CUSTOM          1
#define LV_TICK_CUSTOM_INCLUDE  "Arduino.h"
#define LV_TICK_CUSTOM_SYS_TIME_EXPR (millis())

#define LV_DISP_DEF_REFR_PERIOD 20
#define LV_INDEV_DEF_READ_PERIOD 20

#define LV_USE_LOG              0
#define LV_USE_PERF_MONITOR     0

#define LV_FONT_MONTSERRAT_10   1
#define LV_FONT_MONTSERRAT_16   1
#define LV_FONT_MONTSERRAT_40   1
#define LV_FONT_DEFAULT         &lv_font_montserrat_16

#define LV_USE_THEME_DEFAULT    1
#define LV_THEME_DEFAULT_DARK   1

#endif
