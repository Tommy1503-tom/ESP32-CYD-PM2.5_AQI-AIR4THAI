#pragma once
/*
 * ตัวสแกนสตรีม + ตัวแยกข้อมูล Air4Thai (ไม่พึ่ง Arduino -> ทดสอบบนคอมได้)
 *
 * ไฟล์ getNewAQI_JSON.php มีขนาดใหญ่ (ทุกสถานี) เกินกว่าจะเก็บใน RAM ของ ESP32
 * จึงอ่านทีละไบต์จากสตรีม หาเฉพาะสถานีที่ต้องการ แล้วเก็บแค่ออบเจ็กต์ของสถานีนั้น
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <string>
#include <ArduinoJson.h>

struct Reading {
  char  name[120] = "";
  char  area[160] = "";
  char  mdate[12] = "";   // วันที่ของข้อมูลสถานี (YYYY-MM-DD)
  char  mtime[8]  = "";   // เวลาของข้อมูลสถานี (HH:MM)
  char  param[8]  = "";   // สารมลพิษหลักของ AQI รวม
  float pm   = -1;        // PM2.5 (ug/m3)
  int   pmAqi = -1;       // AQI ย่อยของ PM2.5
  int   aqi  = -1;        // AQI รวม
};

class StationScanner {
public:
  static const size_t MAX_BODY = 6144;

  bool found = false, done = false, overflow = false;

  explicit StationScanner(const char* stationId) {
    snprintf(id_, sizeof(id_), "%s", stationId);
    plen_ = snprintf(pat_, sizeof(pat_), "\"stationID\":\"%s\"", id_);
    if (plen_ < 0 || plen_ >= (int)sizeof(pat_)) plen_ = 0;
    body_ = (char*)malloc(MAX_BODY + 1);
    if (body_) body_[0] = 0;
  }
  ~StationScanner() { free(body_); }

  const char* id() const { return id_; }
  const char* body() const { return body_ ? body_ : ""; }
  size_t bodyLen() const { return blen_; }

  // คืน false เมื่อไม่ต้องรับข้อมูลต่อแล้ว (เจอครบ หรือผิดพลาด)
  bool feed(const uint8_t* p, size_t n) {
    for (size_t i = 0; i < n; i++) {
      feed1(p[i]);
      if (done) return false;
    }
    return true;
  }

private:
  char  id_[24];
  char  pat_[48];
  int   plen_ = 0;
  char  ring_[48];
  int   rpos_ = 0, filled_ = 0;
  char* body_ = nullptr;
  size_t blen_ = 0;
  int   depth_ = 0;
  bool  inStr_ = false, esc_ = false;

  void feed1(uint8_t c) {
    if (done) return;
    if (!body_ || plen_ == 0) { overflow = true; done = true; return; }

    if (!found) {
      if (c == ' ' || c == '\n' || c == '\r' || c == '\t') return;   // ข้ามช่องว่างนอกสตริง
      ring_[rpos_] = (char)c;
      rpos_ = (rpos_ + 1) % plen_;
      if (filled_ < plen_) filled_++;
      if (c == '"' && filled_ == plen_) {
        bool ok = true;
        for (int i = 0; i < plen_; i++)
          if (pat_[i] != ring_[(rpos_ + i) % plen_]) { ok = false; break; }
        if (ok) { found = true; depth_ = 1; inStr_ = false; esc_ = false; }
      }
      return;
    }

    // เก็บส่วนที่เหลือของออบเจ็กต์สถานีจนปีกกาปิด
    if (blen_ >= MAX_BODY) { overflow = true; done = true; return; }
    body_[blen_++] = (char)c;
    body_[blen_] = 0;

    if (esc_) { esc_ = false; return; }
    if (inStr_) {
      if (c == '\\') esc_ = true;
      else if (c == '"') inStr_ = false;
      return;
    }
    if (c == '"') inStr_ = true;
    else if (c == '{') depth_++;
    else if (c == '}') { if (--depth_ == 0) done = true; }
  }
};

static inline void a4tCopy(char* dst, size_t n, const char* src) {
  if (!src) src = "";
  snprintf(dst, n, "%s", src);
}

static inline float a4tNum(JsonVariantConst v, float def) {
  if (v.isNull()) return def;
  if (v.is<const char*>()) {
    const char* s = v.as<const char*>();
    if (!s || !*s) return def;
    return (float)atof(s);
  }
  return v.as<float>();
}

// 0 = สำเร็จ, 1 = JSON ผิดรูปแบบ, 2 = สถานีไม่มีค่า PM2.5
static inline int a4tParse(const StationScanner& sc, Reading& r) {
  std::string full = std::string("{\"stationID\":\"") + sc.id() + "\"" + sc.body();
  JsonDocument doc;
  if (deserializeJson(doc, full)) return 1;

  a4tCopy(r.name, sizeof(r.name), doc["nameTH"] | "");
  a4tCopy(r.area, sizeof(r.area), doc["areaTH"] | "");

  JsonVariantConst last = doc["AQILast"];
  a4tCopy(r.mdate, sizeof(r.mdate), last["date"] | "");
  a4tCopy(r.mtime, sizeof(r.mtime), last["time"] | "");

  r.pm    = a4tNum(last["PM25"]["value"], -1);
  r.pmAqi = (int)a4tNum(last["PM25"]["aqi"], -1);
  r.aqi   = (int)a4tNum(last["AQI"]["aqi"], -1);
  const char* par = last["AQI"]["param"] | "";
  if (!strcasecmp(par, "PM25") || !strcasecmp(par, "PM2.5")) par = "PM2.5";
  a4tCopy(r.param, sizeof(r.param), par);

  if (r.pm < 0 || r.pm > 999.9f) return 2;
  return 0;
}
