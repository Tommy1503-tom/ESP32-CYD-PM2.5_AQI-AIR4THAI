/*
 * Air Quality Monitor (PM2.5 / AQI)  -  ESP32-2432S028 (CYD) + LVGL 8.3
 * ข้อมูล: Air4Thai (กรมควบคุมมลพิษ)  getNewAQI_JSON.php
 * แสดงผลภาษาไทย | Pilot lamp เขียว/เหลือง/แดง | Seven segment ผ่าน Modbus RTU (RS485)
 */
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <SPI.h>
#include <time.h>
#include <lvgl.h>
#include <TFT_eSPI.h>
#include <XPT2046_Touchscreen.h>
#include "air4thai_parse.h"

// =====================================================================
//                       ส่วนตั้งค่า (แก้ตรงนี้)
// =====================================================================
#define WIFI_SSID          "YOUR_WIFI_SSID"
#define WIFI_PASS          "YOUR_WIFI_PASSWORD"

// ---- Air4Thai ----
#define AIR4THAI_URL       "http://air4thai.pcd.go.th/services/getNewAQI_JSON.php"
#define STATION_ID         "02t"      // *** รหัสสถานี เปิด URL ข้างบนแล้วค้นหา "stationID" ของพื้นที่คุณ ***
#define POLL_MS            300000UL   // ดึงข้อมูลทุก 5 นาที (ข้อมูลสถานีอัปเดตรายชั่วโมง อย่าตั้งถี่เกินไป)
#define RETRY_MS           30000UL    // ถ้าดึงไม่สำเร็จ ลองใหม่ทุก 30 วินาที
#define STALE_MS           1200000UL  // ไม่มีข้อมูลใหม่เกิน 20 นาที = ขาดการติดต่อ
#define DATA_OLD_MIN       180        // ข้อมูลของสถานีเก่ากว่านี้ (นาที) จะแสดงเป็นสีส้ม

// ---- Pilot lamp (ผ่านรีเลย์/ทรานซิสเตอร์เท่านั้น ห้ามต่อหลอด 24V/220V เข้า GPIO ตรงๆ) ----
#define ENABLE_LAMPS       1
#define LAMP_GREEN_PIN     22
#define LAMP_YELLOW_PIN    16   // ขาเดียวกับ LED RGB บนบอร์ด (สีเขียว) ต้องบัดกรีออกมาใช้
#define LAMP_RED_PIN       4    // ขาเดียวกับ LED RGB บนบอร์ด (สีแดง)  ต้องบัดกรีออกมาใช้
#define LAMP_ACTIVE_LEVEL  HIGH

// ---- Seven segment ผ่าน Modbus RTU (RS485) ----
#define ENABLE_SEG485      1
#define SEG_TX_PIN         27   // -> DI ของโมดูล RS485
#define SEG_RX_PIN         35   // <- RO ของโมดูล RS485 (GPIO35 เป็น input อย่างเดียว ใช้เป็น RX ได้)
#define SEG_DE_PIN         -1   // ขา DE/RE ถ้าโมดูลไม่ใช่แบบ Auto direction (-1 = ไม่ใช้)
#define SEG_BAUD           9600
#define SEG_SLAVE_ID       1
#define SEG_FUNC           6    // 6 = Write Single Register, 16 = Write Multiple Registers
#define SEG_REG_ADDR       0    // *** ที่อยู่ Register ที่เซเว่นเซกเมนต์ใช้แสดงค่า ***
#define SEG_SCALE          10.0f// ค่าที่เขียน = PM2.5 x SEG_SCALE (27.2 -> 272)
#define SEG_REFRESH_MS     5000 // เขียนซ้ำทุกกี่ ms

// ---- กราฟ ----
#define HIST_POINTS        24   // เก็บ 24 จุด (ข้อมูลใหม่รายชั่วโมง = ย้อนหลัง 24 ชม.)

// ---- หน้าจอ/ทัช ----
#define SCREEN_W           320
#define SCREEN_H           240
#define AUTO_PAGE_IDLE_MS  15000
#define XPT_CS             33
#define XPT_IRQ            36
#define XPT_CLK            25
#define XPT_MOSI           32
#define XPT_MISO           39
#define TOUCH_ROT          1
#define TOUCH_INVERT_X     0
#define TOUCH_INVERT_Y     0

// =====================================================================
//                       ฟอนต์ / ข้อความ
// =====================================================================
LV_FONT_DECLARE(font_thai_16);
LV_FONT_DECLARE(font_thai_24);
#define FONT_S   (&font_thai_16)   // สูง 26 px
#define FONT_L   (&font_thai_24)   // สูง 34 px
#define FONT_NUM (&lv_font_montserrat_40)
#define UNIT_TXT "µg/m³"

static const char* MONTHS[12] = {"ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.",
                                 "ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."};

// =====================================================================
//                  เกณฑ์ AQI กรมควบคุมมลพิษ (คพ.) ประเทศไทย
// =====================================================================
enum { LAMP_G = 0, LAMP_Y = 1, LAMP_R = 2 };

struct Band {
  float cLo, cHi;      // ช่วง PM2.5 (µg/m³) ใช้คำนวณ AQI สำรองเมื่อ API ไม่ส่ง AQI มา
  int   aLo, aHi;      // ช่วง AQI
  uint32_t color;
  const char* name;
  const char* advice;
  uint8_t lamp;
};

static const Band BANDS[] = {
  {  0.0f,  15.0f,   0,  25, 0x00B5E2, "ดีมาก",
     "เหมาะกับกิจกรรมกลางแจ้ง", LAMP_G},
  { 15.1f,  25.0f,  26,  50, 0x2ECC71, "ดี",
     "ทำกิจกรรมกลางแจ้งได้ตามปกติ", LAMP_G},
  { 25.1f,  37.5f,  51, 100, 0xF5C518, "ปานกลาง",
     "ผู้ป่วยควรลดกิจกรรมกลางแจ้ง", LAMP_Y},
  { 37.6f,  75.0f, 101, 200, 0xFF8C1A, "กระทบสุขภาพบางกลุ่ม",
     "ลดกิจกรรมกลางแจ้ง สวมหน้ากาก", LAMP_R},
  { 75.1f, 250.0f, 201, 500, 0xE53935, "มีผลกระทบต่อสุขภาพ",
     "งดกิจกรรมกลางแจ้ง สวมหน้ากาก", LAMP_R},
};
static const int N_BANDS = sizeof(BANDS) / sizeof(BANDS[0]);

static int bandByAqi(int aqi) {
  for (int i = 0; i < N_BANDS; i++) if (aqi <= BANDS[i].aHi) return i;
  return N_BANDS - 1;
}

static int aqiFromPm(float c) {
  int i = 0;
  while (i < N_BANDS - 1 && c > BANDS[i].cHi) i++;
  const Band& b = BANDS[i];
  float v = (float)(b.aHi - b.aLo) / (b.cHi - b.cLo) * (c - b.cLo) + b.aLo;
  if (v < b.aLo) v = b.aLo;
  if (v > 500) v = 500;
  return (int)lroundf(v);
}

// =====================================================================
//                       ข้อมูลที่แชร์ระหว่าง Task
// =====================================================================
enum Status : uint8_t { ST_WAIT = 0, ST_OK, ST_NET_FAIL, ST_NO_STATION, ST_NO_DATA };

struct Shared {
  Status   status = ST_WAIT;
  bool     everOk = false;
  uint32_t lastOkMs = 0;
  time_t   lastOkTime = 0;       // เวลาที่ ESP32 อ่านค่าสำเร็จ
  Reading  r;                    // ข้อมูลล่าสุดจากสถานี
  int      aqi = 0;
  int      band = 0;
  // ประวัติสำหรับกราฟ
  uint8_t  hn = 0;
  uint16_t hpm10[HIST_POINTS] = {0};   // PM2.5 x10
  int16_t  haqi[HIST_POINTS]  = {0};
  uint32_t histVer = 0;
};
static Shared gData;
static SemaphoreHandle_t gMux;
static Preferences prefs;
static char gLastStamp[24] = "";     // "วันที่ เวลา" ของข้อมูลสถานีที่บันทึกลงกราฟล่าสุด

static void histLoad() {
  prefs.begin("aq", false);
  uint8_t n = prefs.getUChar("n", 0);
  if (n > HIST_POINTS) n = 0;
  if (n > 0 &&
      prefs.getBytes("pm", gData.hpm10, sizeof(gData.hpm10)) == sizeof(gData.hpm10) &&
      prefs.getBytes("aqi", gData.haqi, sizeof(gData.haqi)) == sizeof(gData.haqi)) {
    gData.hn = n;
  }
  String st = prefs.getString("ts", "");
  snprintf(gLastStamp, sizeof(gLastStamp), "%s", st.c_str());
  gData.histVer++;
}

// =====================================================================
//                       Modbus RTU -> Seven segment
// =====================================================================
static uint16_t crc16(const uint8_t* d, size_t n) {
  uint16_t c = 0xFFFF;
  for (size_t i = 0; i < n; i++) {
    c ^= d[i];
    for (int b = 0; b < 8; b++) c = (c & 1) ? (c >> 1) ^ 0xA001 : (c >> 1);
  }
  return c;
}

static void segInit() {
#if ENABLE_SEG485
  Serial2.begin(SEG_BAUD, SERIAL_8N1, SEG_RX_PIN, SEG_TX_PIN);
  if (SEG_DE_PIN >= 0) { pinMode(SEG_DE_PIN, OUTPUT); digitalWrite(SEG_DE_PIN, LOW); }
#endif
}

static void segWrite(float pm) {
#if ENABLE_SEG485
  float v = pm * SEG_SCALE;
  if (v < 0) v = 0;
  if (v > 65535) v = 65535;
  uint16_t val = (uint16_t)lroundf(v);

  uint8_t f[16];
  size_t n = 0;
  f[n++] = SEG_SLAVE_ID;
  f[n++] = SEG_FUNC;
  f[n++] = SEG_REG_ADDR >> 8;
  f[n++] = SEG_REG_ADDR & 0xFF;
  if (SEG_FUNC == 16) { f[n++] = 0; f[n++] = 1; f[n++] = 2; }
  f[n++] = val >> 8;
  f[n++] = val & 0xFF;
  uint16_t crc = crc16(f, n);
  f[n++] = crc & 0xFF;          // CRC low ก่อน
  f[n++] = crc >> 8;

  while (Serial2.available()) Serial2.read();
  if (SEG_DE_PIN >= 0) digitalWrite(SEG_DE_PIN, HIGH);
  Serial2.write(f, n);
  Serial2.flush();
  if (SEG_DE_PIN >= 0) digitalWrite(SEG_DE_PIN, LOW);
  Serial.printf("[SEG] id=%d reg=%d value=%u\n", SEG_SLAVE_ID, SEG_REG_ADDR, val);
#endif
}

// =====================================================================
//                       ดึงข้อมูล Air4Thai (สตรีม)
// =====================================================================
class ScanStream : public Stream {
public:
  explicit ScanStream(StationScanner& s) : sc(s) {}
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  size_t write(uint8_t c) override { return sc.feed(&c, 1) ? 1 : 0; }
  size_t write(const uint8_t* b, size_t n) override { return sc.feed(b, n) ? n : 0; }
private:
  StationScanner& sc;
};

// 0 = ได้ข้อมูล, 1 = เครือข่ายล้มเหลว, 2 = ไม่พบสถานี, 3 = JSON ผิด/สถานีไม่มี PM2.5
static int fetchStation(Reading& out) {
  String url = AIR4THAI_URL;

  for (int hop = 0; hop < 4; hop++) {
    const bool https = url.startsWith("https://");
    WiFiClient plain;
    WiFiClientSecure secure;
    HTTPClient http;
    http.setConnectTimeout(8000);
    http.setTimeout(20000);
    http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
    http.setUserAgent("ESP32-AQI-Monitor/1.0");
    const char* hdrs[] = {"Location"};
    http.collectHeaders(hdrs, 1);

    bool began;
    if (https) { secure.setInsecure(); began = http.begin(secure, url); }
    else       { began = http.begin(plain, url); }
    if (!began) return 1;

    int code = http.GET();
    Serial.printf("[HTTP] GET %s -> %d\n", url.c_str(), code);

    if (code == 301 || code == 302 || code == 307 || code == 308) {
      String loc = http.header("Location");
      http.end();
      if (loc.length() == 0) return 1;
      if (loc.startsWith("/")) {                       // Location แบบ relative
        int p = url.indexOf("://");
        int q = url.indexOf('/', p + 3);
        loc = url.substring(0, q < 0 ? url.length() : q) + loc;
      }
      url = loc;
      continue;
    }
    if (code != 200) { http.end(); return 1; }

    StationScanner sc(STATION_ID);
    ScanStream ss(sc);
    http.writeToStream(&ss);       // หยุดดาวน์โหลดเองทันทีที่เจอสถานีครบ
    http.end();

    if (sc.overflow) return 3;
    if (!sc.found)   return 2;
    if (!sc.done)    return 1;     // สตรีมขาดกลางทาง

    int rc = a4tParse(sc, out);
    if (rc == 0) return 0;
    return 3;
  }
  return 1;
}

static void netTask(void*) {
  bool ntpStarted = false;
  uint32_t lastWifiTry = 0, nextFetch = 0, nextSeg = 0;

  for (;;) {
    uint32_t now = millis();

    if (WiFi.status() != WL_CONNECTED) {
      if (now - lastWifiTry > 15000) {
        lastWifiTry = now;
        WiFi.disconnect();
        WiFi.begin(WIFI_SSID, WIFI_PASS);
        Serial.println("[WiFi] reconnecting...");
      }
      vTaskDelay(pdMS_TO_TICKS(500));
      continue;
    }
    if (!ntpStarted) {
      configTzTime("ICT-7", "th.pool.ntp.org", "pool.ntp.org", "time.google.com");
      ntpStarted = true;
      nextFetch = now;
      Serial.printf("[WiFi] connected, IP=%s\n", WiFi.localIP().toString().c_str());
    }

    if ((int32_t)(now - nextFetch) >= 0) {
      Reading r;
      int rc = fetchStation(r);

      xSemaphoreTake(gMux, portMAX_DELAY);
      if (rc == 0) {
        int aqi = r.aqi;
        if (aqi < 0) aqi = r.pmAqi;
        if (aqi < 0) aqi = aqiFromPm(r.pm);
        time_t t = time(nullptr);
        char stamp[24];
        snprintf(stamp, sizeof(stamp), "%s %s", r.mdate, r.mtime);
        bool newReading = strcmp(stamp, gLastStamp) != 0;
        gData.r = r;
        gData.aqi = aqi;
        gData.band = bandByAqi(aqi);
        gData.status = ST_OK;
        gData.everOk = true;
        gData.lastOkMs = millis();
        gData.lastOkTime = (t > 1700000000) ? t : 0;

        // เพิ่มจุดกราฟเมื่อสถานีส่งข้อมูลรอบใหม่ (รายชั่วโมง)
        if (newReading) {
          if (gData.hn == HIST_POINTS) {
            memmove(gData.hpm10, gData.hpm10 + 1, (HIST_POINTS - 1) * sizeof(uint16_t));
            memmove(gData.haqi, gData.haqi + 1, (HIST_POINTS - 1) * sizeof(int16_t));
            gData.hn--;
          }
          gData.hpm10[gData.hn] = (uint16_t)lroundf(r.pm * 10.0f);
          gData.haqi[gData.hn]  = (int16_t)aqi;
          gData.hn++;
          gData.histVer++;
          snprintf(gLastStamp, sizeof(gLastStamp), "%s", stamp);
          prefs.putString("ts", stamp);
          prefs.putUChar("n", gData.hn);
          prefs.putBytes("pm", gData.hpm10, sizeof(gData.hpm10));
          prefs.putBytes("aqi", gData.haqi, sizeof(gData.haqi));
        }
        Serial.printf("[AQI] %s %s PM2.5=%.1f AQI=%d (%s)\n", r.mdate, r.mtime, r.pm, aqi, r.param);
        nextFetch = millis() + POLL_MS;
        nextSeg = 0;   // เขียนไปที่เซเว่นเซกเมนต์ทันที
      } else {
        gData.status = (rc == 2) ? ST_NO_STATION : (rc == 3 ? ST_NO_DATA : ST_NET_FAIL);
        Serial.printf("[AQI] fetch failed rc=%d\n", rc);
        nextFetch = millis() + RETRY_MS;
      }
      xSemaphoreGive(gMux);
    }

    // เขียนค่าไป Seven segment เป็นระยะ (ถ้าข้อมูลยังไม่เก่าเกินไป)
    if ((int32_t)(millis() - nextSeg) >= 0) {
      float pm = -1;
      xSemaphoreTake(gMux, portMAX_DELAY);
      if (gData.everOk && (millis() - gData.lastOkMs < STALE_MS)) pm = gData.r.pm;
      xSemaphoreGive(gMux);
      if (pm >= 0) segWrite(pm);
      nextSeg = millis() + SEG_REFRESH_MS;
    }

    vTaskDelay(pdMS_TO_TICKS(200));
  }
}

// =====================================================================
//                       Pilot lamp
// =====================================================================
static void lampsInit() {
#if ENABLE_LAMPS
  const int pins[3] = {LAMP_GREEN_PIN, LAMP_YELLOW_PIN, LAMP_RED_PIN};
  for (int p : pins) { pinMode(p, OUTPUT); digitalWrite(p, !LAMP_ACTIVE_LEVEL); }
#endif
}

// group: 0=เขียว 1=เหลือง 2=แดง, -1 = ดับหมด
static void setLamps(int group) {
#if ENABLE_LAMPS
  digitalWrite(LAMP_GREEN_PIN,  (group == LAMP_G) ? LAMP_ACTIVE_LEVEL : !LAMP_ACTIVE_LEVEL);
  digitalWrite(LAMP_YELLOW_PIN, (group == LAMP_Y) ? LAMP_ACTIVE_LEVEL : !LAMP_ACTIVE_LEVEL);
  digitalWrite(LAMP_RED_PIN,    (group == LAMP_R) ? LAMP_ACTIVE_LEVEL : !LAMP_ACTIVE_LEVEL);
#endif
}

// =====================================================================
//                       Display / Touch driver
// =====================================================================
TFT_eSPI tft = TFT_eSPI();
SPIClass touchSPI(VSPI);
XPT2046_Touchscreen ts(XPT_CS, XPT_IRQ);

#define DRAW_LINES 30
static lv_disp_draw_buf_t drawBuf;
static lv_color_t buf1[SCREEN_W * DRAW_LINES];

static void flushCb(lv_disp_drv_t* d, const lv_area_t* a, lv_color_t* c) {
  uint32_t w = a->x2 - a->x1 + 1, h = a->y2 - a->y1 + 1;
  tft.startWrite();
  tft.setAddrWindow(a->x1, a->y1, w, h);
  tft.pushColors((uint16_t*)&c->full, w * h, true);
  tft.endWrite();
  lv_disp_flush_ready(d);
}

static void touchReadCb(lv_indev_drv_t*, lv_indev_data_t* data) {
  if (ts.tirqTouched() && ts.touched()) {
    TS_Point p = ts.getPoint();
    int x = map(p.x, 200, 3700, 0, SCREEN_W - 1);
    int y = map(p.y, 240, 3800, 0, SCREEN_H - 1);
#if TOUCH_INVERT_X
    x = SCREEN_W - 1 - x;
#endif
#if TOUCH_INVERT_Y
    y = SCREEN_H - 1 - y;
#endif
    data->point.x = constrain(x, 0, SCREEN_W - 1);
    data->point.y = constrain(y, 0, SCREEN_H - 1);
    data->state = LV_INDEV_STATE_PR;
  } else {
    data->state = LV_INDEV_STATE_REL;
  }
}

// =====================================================================
//                       UI
// =====================================================================
static lv_obj_t *tv, *tile1, *tile2;
static lv_obj_t *wifiIcon, *lblNow, *lblRead, *lblStation, *lblDataTime;
static lv_obj_t *lblPm, *lblAqi, *lblAqiFrom, *banner, *lblBandCap, *lblBandName, *lblAdvice;
static lv_obj_t *hdrPm, *hdrAqi, *chartPm, *chartAqi;
static lv_chart_series_t *serPm, *serAqi;
static uint32_t shownHistVer = 0xFFFFFFFF;
static char lastStation[300] = "";

static lv_obj_t* mkLabel(lv_obj_t* p, const lv_font_t* f, uint32_t col, const char* txt) {
  lv_obj_t* l = lv_label_create(p);
  lv_obj_set_style_text_font(l, f, 0);
  lv_obj_set_style_text_color(l, lv_color_hex(col), 0);
  lv_label_set_text(l, txt);
  return l;
}

static lv_obj_t* mkCard(lv_obj_t* p, int x, int y, int w, int h, uint32_t col) {
  lv_obj_t* c = lv_obj_create(p);
  lv_obj_remove_style_all(c);
  lv_obj_set_pos(c, x, y);
  lv_obj_set_size(c, w, h);
  lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
  lv_obj_set_style_bg_color(c, lv_color_hex(col), 0);
  lv_obj_set_style_radius(c, 12, 0);
  lv_obj_clear_flag(c, LV_OBJ_FLAG_SCROLLABLE);
  return c;
}

static lv_obj_t* mkChart(lv_obj_t* p, int y, lv_chart_series_t** ser) {
  lv_obj_t* ch = lv_chart_create(p);
  lv_obj_set_pos(ch, 42, y);
  lv_obj_set_size(ch, 270, 84);
  lv_chart_set_type(ch, LV_CHART_TYPE_LINE);
  lv_chart_set_point_count(ch, 2);
  lv_chart_set_div_line_count(ch, 4, 0);
  lv_obj_set_style_bg_color(ch, lv_color_hex(0x182235), 0);
  lv_obj_set_style_bg_opa(ch, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(ch, 0, 0);
  lv_obj_set_style_radius(ch, 8, 0);
  lv_obj_set_style_pad_all(ch, 4, 0);
  lv_obj_set_style_line_color(ch, lv_color_hex(0x2A3A55), LV_PART_MAIN);
  lv_obj_set_style_size(ch, 5, LV_PART_INDICATOR);
  lv_obj_set_style_line_width(ch, 2, LV_PART_ITEMS);
  lv_chart_set_axis_tick(ch, LV_CHART_AXIS_PRIMARY_Y, 4, 2, 5, 1, true, 36);
  lv_obj_set_style_text_font(ch, &lv_font_montserrat_10, LV_PART_TICKS);
  lv_obj_set_style_text_color(ch, lv_color_hex(0x9AA7BC), LV_PART_TICKS);
  *ser = lv_chart_add_series(ch, lv_color_hex(0x4FC3F7), LV_CHART_AXIS_PRIMARY_Y);
  lv_chart_set_all_value(ch, *ser, LV_CHART_POINT_NONE);
  lv_chart_set_range(ch, LV_CHART_AXIS_PRIMARY_Y, 0, 100);
  return ch;
}

static void buildUi() {
  lv_obj_t* scr = lv_scr_act();
  lv_obj_set_style_bg_color(scr, lv_color_hex(0x0B1220), 0);
  lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);

  tv = lv_tileview_create(scr);
  lv_obj_set_size(tv, SCREEN_W, SCREEN_H);
  lv_obj_set_pos(tv, 0, 0);
  lv_obj_set_style_bg_color(tv, lv_color_hex(0x0B1220), 0);
  lv_obj_set_style_bg_opa(tv, LV_OPA_COVER, 0);
  lv_obj_set_style_pad_all(tv, 0, 0);
  lv_obj_set_style_border_width(tv, 0, 0);
  lv_obj_set_style_radius(tv, 0, 0);
  lv_obj_set_scrollbar_mode(tv, LV_SCROLLBAR_MODE_OFF);

  tile1 = lv_tileview_add_tile(tv, 0, 0, LV_DIR_RIGHT);
  tile2 = lv_tileview_add_tile(tv, 1, 0, LV_DIR_LEFT);
  lv_obj_t* tiles[2] = {tile1, tile2};
  for (auto t : tiles) {
    lv_obj_set_style_bg_opa(t, LV_OPA_TRANSP, 0);
    lv_obj_set_style_pad_all(t, 0, 0);
    lv_obj_set_style_border_width(t, 0, 0);
    lv_obj_set_style_radius(t, 0, 0);
  }

  // ---------------- หน้า 1 : ตัวเลข ----------------
  lv_obj_t* hdr = mkCard(tile1, 0, 0, SCREEN_W, 28, 0x111A2B);
  lv_obj_set_style_radius(hdr, 0, 0);
  wifiIcon = mkLabel(tile1, &lv_font_montserrat_16, 0xE53935, LV_SYMBOL_WIFI);
  lv_obj_set_pos(wifiIcon, 8, 5);
  lblNow = mkLabel(tile1, FONT_S, 0xFFFFFF, "--:--:--");
  lv_obj_set_pos(lblNow, 32, 1);
  lblRead = mkLabel(tile1, FONT_S, 0x9AA7BC, "อ่านค่า --:--:--");
  lv_obj_align(lblRead, LV_ALIGN_TOP_RIGHT, -8, 1);

  // บรรทัดสถานี + เวลาข้อมูลของสถานี
  lblStation = mkLabel(tile1, FONT_S, 0x4FC3F7, "");
  lv_obj_set_width(lblStation, 215);
  lv_label_set_long_mode(lblStation, LV_LABEL_LONG_SCROLL_CIRCULAR);
  lv_obj_set_pos(lblStation, 8, 28);
  lblDataTime = mkLabel(tile1, FONT_S, 0x9AA7BC, "");
  lv_obj_align(lblDataTime, LV_ALIGN_TOP_RIGHT, -8, 28);

  // การ์ด PM2.5
  lv_obj_t* cardPm = mkCard(tile1, 6, 57, 151, 92, 0x182235);
  lv_obj_t* capPm = mkLabel(cardPm, FONT_S, 0x9AA7BC, "ฝุ่น PM2.5");
  lv_obj_align(capPm, LV_ALIGN_TOP_LEFT, 6, 0);
  lv_obj_t* unit = mkLabel(cardPm, FONT_S, 0x9AA7BC, UNIT_TXT);
  lv_obj_align(unit, LV_ALIGN_TOP_RIGHT, -6, 0);
  lblPm = mkLabel(cardPm, FONT_NUM, 0xFFFFFF, "--");
  lv_obj_align(lblPm, LV_ALIGN_CENTER, 0, 14);

  // การ์ด AQI
  lv_obj_t* cardAqi = mkCard(tile1, 163, 57, 151, 92, 0x182235);
  lv_obj_t* capAqi = mkLabel(cardAqi, FONT_S, 0x9AA7BC, "ดัชนี AQI");
  lv_obj_align(capAqi, LV_ALIGN_TOP_LEFT, 6, 0);
  lblAqiFrom = mkLabel(cardAqi, FONT_S, 0x9AA7BC, "");
  lv_obj_align(lblAqiFrom, LV_ALIGN_TOP_RIGHT, -6, 0);
  lblAqi = mkLabel(cardAqi, FONT_NUM, 0xFFFFFF, "--");
  lv_obj_align(lblAqi, LV_ALIGN_CENTER, 0, 14);

  // แถบระดับคุณภาพอากาศ
  banner = mkCard(tile1, 6, 152, 308, 62, 0x59657A);
  lblBandCap = mkLabel(banner, FONT_S, 0x10151F, "ระดับคุณภาพอากาศ");
  lv_obj_align(lblBandCap, LV_ALIGN_TOP_MID, 0, 0);
  lblBandName = mkLabel(banner, FONT_L, 0x10151F, "รอข้อมูล...");
  lv_obj_align(lblBandName, LV_ALIGN_BOTTOM_MID, 0, 0);

  // คำแนะนำ / สถานะ
  lblAdvice = mkLabel(tile1, FONT_S, 0xCFD8E3, "");
  lv_obj_set_width(lblAdvice, 280);
  lv_label_set_long_mode(lblAdvice, LV_LABEL_LONG_CLIP);
  lv_obj_set_style_text_align(lblAdvice, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_align(lblAdvice, LV_ALIGN_BOTTOM_MID, -8, 0);
  lv_obj_t* arrow = mkLabel(tile1, &lv_font_montserrat_16, 0x6F7F99, LV_SYMBOL_RIGHT);
  lv_obj_align(arrow, LV_ALIGN_BOTTOM_RIGHT, -6, -4);

  // ---------------- หน้า 2 : กราฟ ----------------
  hdrPm = mkLabel(tile2, FONT_S, 0xFFFFFF, "PM2.5 (" UNIT_TXT ")");
  lv_obj_set_pos(hdrPm, 8, 0);
  chartPm = mkChart(tile2, 28, &serPm);

  hdrAqi = mkLabel(tile2, FONT_S, 0xFFFFFF, "AQI");
  lv_obj_set_pos(hdrAqi, 8, 116);
  chartAqi = mkChart(tile2, 144, &serAqi);
}

// ---------------------------------------------------------------------
static uint32_t textOn(uint32_t c) {
  int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
  return ((r * 299 + g * 587 + b * 114) / 1000 > 120) ? 0x10151F : 0xFFFFFF;
}

static void redrawCharts(const Shared& s) {
  int n = s.hn;
  int cnt = (n < 2) ? 2 : n;
  lv_chart_set_point_count(chartPm, cnt);
  lv_chart_set_point_count(chartAqi, cnt);

  int mp = 0, ma = 0;
  for (int i = 0; i < cnt; i++) {
    if (i < n) {
      int pv = (int)lroundf(s.hpm10[i] / 10.0f);
      int av = s.haqi[i];
      if (pv > mp) mp = pv;
      if (av > ma) ma = av;
      lv_chart_set_value_by_id(chartPm, serPm, i, pv);
      lv_chart_set_value_by_id(chartAqi, serAqi, i, av);
    } else {
      lv_chart_set_value_by_id(chartPm, serPm, i, LV_CHART_POINT_NONE);
      lv_chart_set_value_by_id(chartAqi, serAqi, i, LV_CHART_POINT_NONE);
    }
  }
  int hiP = ((mp * 11 / 10) / 10 + 1) * 10; if (hiP < 50)  hiP = 50;
  int hiA = ((ma * 11 / 10) / 50 + 1) * 50; if (hiA < 100) hiA = 100;
  lv_chart_set_range(chartPm,  LV_CHART_AXIS_PRIMARY_Y, 0, hiP);
  lv_chart_set_range(chartAqi, LV_CHART_AXIS_PRIMARY_Y, 0, hiA);

  lv_color_t c = lv_color_hex(BANDS[s.band].color);
  lv_chart_set_series_color(chartPm,  serPm,  c);
  lv_chart_set_series_color(chartAqi, serAqi, c);
  lv_chart_refresh(chartPm);
  lv_chart_refresh(chartAqi);

  char hb[96];   // ห้ามใช้ %f กับ lv_label_set_text_fmt (LVGL ไม่เปิดรองรับ float) จึงจัดรูปแบบด้วย snprintf
  snprintf(hb, sizeof(hb), "PM2.5 (%s)  ล่าสุด %.1f  สูงสุด %d", UNIT_TXT, s.r.pm, mp);
  lv_label_set_text(hdrPm, hb);
  snprintf(hb, sizeof(hb), "AQI  ล่าสุด %d  สูงสุด %d  ย้อนหลัง %d ชม.", s.aqi, ma, n);
  lv_label_set_text(hdrAqi, hb);
}

static void uiTimer(lv_timer_t*) {
  Shared s;
  xSemaphoreTake(gMux, portMAX_DELAY);
  s = gData;
  xSemaphoreGive(gMux);

  uint32_t now = millis();
  bool online = s.everOk && (now - s.lastOkMs < STALE_MS);
  char buf[96];
  struct tm tmv;

  // --- เวลาปัจจุบัน ---
  time_t t = time(nullptr);
  bool timeOk = t > 1700000000;
  if (timeOk) {
    localtime_r(&t, &tmv);
    snprintf(buf, sizeof(buf), "%d %s %02d  %02d:%02d:%02d", tmv.tm_mday, MONTHS[tmv.tm_mon],
             (tmv.tm_year + 1900 + 543) % 100, tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
  } else {
    snprintf(buf, sizeof(buf), "--:--:--");
  }
  lv_label_set_text(lblNow, buf);

  // --- เวลาที่อ่านค่า (เวลาที่ ESP32 ดึงข้อมูลสำเร็จ) ---
  if (s.everOk && s.lastOkTime > 0) {
    localtime_r(&s.lastOkTime, &tmv);
    snprintf(buf, sizeof(buf), "อ่านค่า %02d:%02d:%02d", tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
  } else {
    snprintf(buf, sizeof(buf), "อ่านค่า --:--:--");
  }
  lv_label_set_text(lblRead, buf);

  // --- ไอคอนสถานะ ---
  uint32_t wc = (WiFi.status() != WL_CONNECTED) ? 0xE53935 : (online ? 0x2ECC71 : 0xFF8C1A);
  lv_obj_set_style_text_color(wifiIcon, lv_color_hex(wc), 0);

  // --- ชื่อสถานี + เวลาข้อมูลของสถานี ---
  if (s.everOk) {
    char st[300];
    snprintf(st, sizeof(st), "%s | %s", s.r.name, s.r.area);
    if (strcmp(st, lastStation) != 0) {          // เปลี่ยนเฉพาะเมื่อข้อความต่าง เพื่อไม่ให้ตัวอักษรเลื่อนสะดุด
      snprintf(lastStation, sizeof(lastStation), "%s", st);
      lv_label_set_text(lblStation, st);
    }
    snprintf(buf, sizeof(buf), "ข้อมูล %s น.", s.r.mtime);
    lv_label_set_text(lblDataTime, buf);

    bool old = false;
    int y, mo, d, hh, mm;
    if (timeOk && sscanf(s.r.mdate, "%d-%d-%d", &y, &mo, &d) == 3 &&
        sscanf(s.r.mtime, "%d:%d", &hh, &mm) == 2) {
      struct tm m = {};
      m.tm_year = y - 1900; m.tm_mon = mo - 1; m.tm_mday = d; m.tm_hour = hh; m.tm_min = mm;
      m.tm_isdst = -1;
      time_t mt = mktime(&m);
      old = (t - mt) > DATA_OLD_MIN * 60;
    }
    lv_obj_set_style_text_color(lblDataTime, lv_color_hex(old ? 0xFF8C1A : 0x9AA7BC), 0);
  } else {
    lv_label_set_text(lblStation, "สถานี " STATION_ID);
    lv_label_set_text(lblDataTime, "");
  }

  // --- ตัวเลข ---
  uint32_t numCol = online ? 0xFFFFFF : 0x6F7F99;
  if (s.everOk) {
    if (s.r.pm < 100) snprintf(buf, sizeof(buf), "%.1f", s.r.pm);
    else              snprintf(buf, sizeof(buf), "%.0f", s.r.pm);
    lv_label_set_text(lblPm, buf);
    lv_label_set_text_fmt(lblAqi, "%d", s.aqi);
    lv_label_set_text_fmt(lblAqiFrom, "จาก %s", s.r.param[0] ? s.r.param : "PM2.5");
  } else {
    lv_label_set_text(lblPm, "--");
    lv_label_set_text(lblAqi, "--");
    lv_label_set_text(lblAqiFrom, "");
  }
  lv_obj_set_style_text_color(lblPm, lv_color_hex(numCol), 0);
  lv_obj_set_style_text_color(lblAqi, lv_color_hex(numCol), 0);
  lv_obj_align(lblPm, LV_ALIGN_CENTER, 0, 14);
  lv_obj_align(lblAqi, LV_ALIGN_CENTER, 0, 14);

  // --- ระดับคุณภาพอากาศ / ข้อความสถานะ ---
  const char* name; const char* adv; uint32_t col; int lamp = -1;
  if (!s.everOk) {
    name = "รอข้อมูล...";
    if (s.status == ST_NO_STATION)      adv = "ไม่พบรหัสสถานี ตรวจสอบ STATION_ID";
    else if (s.status == ST_NO_DATA)    adv = "สถานีนี้ไม่มีค่า PM2.5";
    else if (s.status == ST_NET_FAIL)   adv = "เชื่อมต่อ Air4Thai ไม่ได้ กำลังลองใหม่";
    else                                adv = "กำลังดึงข้อมูลจาก Air4Thai";
    col = 0x59657A;
  } else if (!online) {
    name = "ขาดการติดต่อ";
    adv  = "ตรวจสอบอินเทอร์เน็ตของอุปกรณ์";
    col  = 0x59657A;
  } else {
    const Band& b = BANDS[s.band];
    name = b.name; adv = b.advice; col = b.color; lamp = b.lamp;
  }
  lv_obj_set_style_bg_color(banner, lv_color_hex(col), 0);
  uint32_t tc = textOn(col);
  lv_obj_set_style_text_color(lblBandCap, lv_color_hex(tc), 0);
  lv_obj_set_style_text_color(lblBandName, lv_color_hex(tc), 0);
  lv_label_set_text(lblBandName, name);
  lv_obj_align(lblBandName, LV_ALIGN_BOTTOM_MID, 0, 0);
  lv_label_set_text(lblAdvice, adv);
  setLamps(lamp);

  // --- กราฟ ---
  if (s.histVer != shownHistVer && s.everOk) {
    shownHistVer = s.histVer;
    redrawCharts(s);
  }
}

static void autoPageTimer(lv_timer_t*) {
  if (lv_disp_get_inactive_time(NULL) < AUTO_PAGE_IDLE_MS) return;
  lv_obj_t* cur = lv_tileview_get_tile_act(tv);
  lv_obj_set_tile(tv, (cur == tile1) ? tile2 : tile1, LV_ANIM_ON);
}

// =====================================================================
//                       setup / loop
// =====================================================================
void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println("\nAir Quality Monitor starting...");

  gMux = xSemaphoreCreateMutex();
  lampsInit();
  segInit();
  histLoad();

  lv_init();
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);

  touchSPI.begin(XPT_CLK, XPT_MISO, XPT_MOSI, XPT_CS);
  ts.begin(touchSPI);
  ts.setRotation(TOUCH_ROT);

  lv_disp_draw_buf_init(&drawBuf, buf1, NULL, SCREEN_W * DRAW_LINES);
  static lv_disp_drv_t dispDrv;
  lv_disp_drv_init(&dispDrv);
  dispDrv.hor_res = SCREEN_W;
  dispDrv.ver_res = SCREEN_H;
  dispDrv.flush_cb = flushCb;
  dispDrv.draw_buf = &drawBuf;
  lv_disp_drv_register(&dispDrv);

  static lv_indev_drv_t indevDrv;
  lv_indev_drv_init(&indevDrv);
  indevDrv.type = LV_INDEV_TYPE_POINTER;
  indevDrv.read_cb = touchReadCb;
  lv_indev_drv_register(&indevDrv);

  buildUi();

  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);

  xTaskCreatePinnedToCore(netTask, "net", 16384, NULL, 1, NULL, 0);

  lv_timer_create(uiTimer, 500, NULL);
  lv_timer_create(autoPageTimer, 5000, NULL);
  uiTimer(NULL);
}

void loop() {
  lv_timer_handler();
  delay(5);
}
